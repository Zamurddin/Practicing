package com.example.SpringBootJpaWithH2DataBase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaWithH2DataBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
