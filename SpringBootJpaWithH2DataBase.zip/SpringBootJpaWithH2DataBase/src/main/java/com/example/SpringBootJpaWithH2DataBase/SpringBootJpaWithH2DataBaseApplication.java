package com.example.SpringBootJpaWithH2DataBase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaWithH2DataBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaWithH2DataBaseApplication.class, args);
	}

}
